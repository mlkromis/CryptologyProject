package org.jcryptool.visual.sha3candidates.views;

import org.eclipse.osgi.util.NLS;

public class Messages extends NLS {
	private static final String BUNDLE_NAME = "org.jcryptool.visual.sha3candidates.views.messages"; //$NON-NLS-1$
	public static String HashingView_0;
	public static String HashingView_1;
	public static String HashingView_10;
	public static String HashingView_11;
	public static String HashingView_12;
	public static String HashingView_13;
	public static String HashingView_14;
	public static String HashingView_15;
	public static String HashingView_16;
	public static String HashingView_17;
	public static String HashingView_18;
	public static String HashingView_2;
	public static String HashingView_21;
	public static String HashingView_3;
	public static String HashingView_4;
	public static String HashingView_5;
	public static String HashingView_6;
	public static String HashingView_7;
	public static String HashingView_8;
	public static String HashingView_9;
	public static String HashingView_mntmCopy_text;
	public static String HashingView_mntmSelectAll_text;
	public static String HashingView_btnUnchanged_text;
	public static String HashingView_btnChanged_text;
	public static String HashingView_01;
	static {
		// initialize resource bundle
		NLS.initializeMessages(BUNDLE_NAME, Messages.class);
	}

	private Messages() {
	}
}
